// Basic
#include <bits/stdc++.h>
#include <ext/pb_ds/assoc_container.hpp>
#include <ext/pb_ds/tree_policy.hpp>
using namespace std;
using namespace __gnu_pbds;
#define endl "\n"
// Loops
#define For(i,l,r) for(int i = l; i < (r); ++i)
#define ForI(i,l,r) for(int i = l; i <= (r); ++i)
#define ForR(i,l,r) for(int i = r-1; i >= 0; i--)
#define ForRI(i,l,r) for(int i = r; i >= (l); i--)
// Shortcuts
#define ___ ios::sync_with_stdio(false);cin.tie(0);
#define pb push_back
#define popb pop_back
#define eb emplace_back
#define sz(a) ((int)((a).size()))
#define ll long long int
// Basic DS
typedef long double ld;
typedef pair<int,int> pii;
typedef pair<ll,ll> pll;
typedef tuple<int, int, int> Tupleiii;
// Vectors
typedef vector<ll> vll;
typedef vector<string> vs;
typedef vector<char> vc;
typedef vector<int> vi;
typedef vector<bool> vb;
typedef vector<pii> vpii;
typedef vector<double> vd;
typedef vector<ld> vld;
// Matrixs
typedef vector<vi> MatrixI;
typedef vector<vc> MatrixC;
typedef vector<vb> MatrixB;
typedef vector<vld> Matrixld;
typedef vector<vpii> MatrixPii;
typedef vector<vll> MatrixLL;


MatrixI Adj;
vi group, dp;
vb visited;

unordered_map <int,int> mp;

void dfs(int source){
    visited[source] = true;

    mp[group[source]]++;
    
    dp[source] = mp.size();
    for(int nbr: Adj[source]){
        if(!visited[nbr]){
            dfs(nbr);
        }
    }
    
    mp[group[source]]--;
    if(mp[group[source]] == 0){
        mp.erase(group[source]);
    }
    return;
}


int main(){___
    int N;
    cin >> N;
    int root;
    // Employees
    visited.resize(N+10);
    group.resize(N+10); dp.resize(N+10);
    Adj.resize(N+1);
    
    ForI(i,1,N){
        int x;
        cin >> x;
        if(x != 0){
            Adj[x].emplace_back(i);
        }
        else{
            root = i;
        }
    }
    ForI(i,1,N){
        cin >> group[i];
    }

    dfs(root);
    
    ForI(i,1,N-1){
        cout << dp[i] << " ";
    }
    cout << dp[N] << endl;

    return 0;
}