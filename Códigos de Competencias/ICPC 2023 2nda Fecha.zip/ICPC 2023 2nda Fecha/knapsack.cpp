#include <bits/stdc++.h>
using namespace std;

#define ___ ios::sync_with_stdio(false);cin.tie(0);

typedef vector<int> vi;
typedef vector<vi> MatrixI;

int N_objetos, M_capacidad;
MatrixI dp;
vi cost;
vi profit;

int knapsack(int object, int capital){
    if(object <= 0 || capital <= 0){
        return 0;
    }
    // Ya calculado
    if(dp[object][capital] != -1){
        return dp[object][capital];
    }
    if(cost[object] > capital){
        dp[object][capital] = knapsack(object-1, capital);
        return dp[object][capital];
    }
    dp[object][capital] = max(knapsack(object-1, capital), knapsack(object, capital-cost[object]) + profit[object]);
    return dp[object][capital];
}


int main(){___
    int N, M;
    cin >> N >> M;

    

    



    return 0;
}