// Basic
#include <bits/stdc++.h>
#include <ext/pb_ds/assoc_container.hpp>
#include <ext/pb_ds/tree_policy.hpp>
using namespace std;
using namespace __gnu_pbds;
#define endl "\n"
// Loops
#define For(i,l,r) for(int i = l; i < (r); ++i)
#define ForI(i,l,r) for(int i = l; i <= (r); ++i)
#define ForR(i,l,r) for(int i = r-1; i >= 0; i--)
#define ForRI(i,l,r) for(int i = r; i >= (l); i--)
// Shortcuts
#define ___ ios::sync_with_stdio(false);cin.tie(0);
#define pb push_back
#define popb pop_back
#define eb emplace_back
#define sz(a) ((int)((a).size()))
#define mp make_pair
#define ll long long int
// Basic DS
typedef long double ld;
typedef pair<int,int> pii;
typedef pair<ll,ll> pll;
typedef tuple<int, int, int> Tupleiii;
// Vectors
typedef vector<ll> vll;
typedef vector<string> vs;
typedef vector<char> vc;
typedef vector<int> vi;
typedef vector<bool> vb;
typedef vector<pii> vpii;
typedef vector<double> vd;
typedef vector<ld> vld;
// Matrixs
typedef vector<vi> MatrixI;
typedef vector<vc> MatrixC;
typedef vector<vb> MatrixB;
typedef vector<vld> Matrixld;
typedef vector<vpii> MatrixPii;
typedef vector<vll> MatrixLL;

//    BITS
#define LSOne(S) ((S) & -(S))  // less significant bit
#define isOn(S, j) (S & (1<<j))
#define setBit(S, j) (S |= (1<<j))
#define clearBit(S, j) (S &= ~(1<<j))
#define toggleBit(S, j) (S ^= (1<<j))
#define lowBit(S) (S & (-S))
#define setAll(S, n) (S = (1<<n)-1)

#define IPOT(S) (!(S & (S-1)))       // isPowerOfTwo ? 1:0
#define modB(S, N) ((S) & (N-1))     // returns S % N, where N is a power of 2
#define NPOT(S) (1<<lround(log2(S))) // nearestPowerOfTwo
#define offLB(S) ((S) & (S-1))       // turnOffLastBit
#define onLZ(S) ((S) | (S+1))        // turnOnLastZero
#define offLCB(S) ((S) & (S+1))      // turnOffLastConsecutiveBits
#define onLCZ(S) ((S) | (S-1))       // turnOnLastConsecutiveZeroes
// count the number of active bits
// 32 bits - __builtin_popcount(S) int
// 64 bits - __builtin_ctz(S)      long long

// Constants
const ld eps = (ld)1e-9;
#define INF 99999999999
const ll mod = 1e9 + 7;
const int MaxN = 1000010;
const int M = 1007;

// Sobrecarga
// Input Operatirons Pair, Vector
template<class T, class V>istream& operator>>(istream &in, pair<T, V> &a) {in >> a.first >> a.second; return in;}
template<class T>istream& operator>>(istream &in, vector<T> &a) {for (auto &i : a) {in >> i;} return in;}
 
// Output Operations Pair, Vector
template<class T, class V>ostream& operator<<(ostream &os, pair<T, V> &a) {os << a.first << " " << a.second; return os;}
template<class T>ostream& operator<<(ostream &os, vector<T> &a) {for (int i = 0 ; i < sz(a) ; i++) {if (i != 0) {os << ' ';} os << a[i];} return os;}

template <class T>
using ordered_set = tree<T, null_type, less<T>, rb_tree_tag, tree_order_statistics_node_update>;

// x-y
// Movements in a Matrix
vpii movements = {{0,1},{1,0},{0,-1},{-1,0}};
//                    Up   Up-Right  Right  Right-Down   Down     Down-Left  Left   Left-Up
// vpii movements = {{0,1}, {1,1}   ,{1,0},    {1,-1}   ,{0,-1},   {-1,-1} ,{-1,0}, {-1,1}} ;

// min heap =  priority_queue <int, vector<int>, greater<int> > pq;

int n,m;
bool possible(int x, int y){
    return x >= 0 and x < n and y >= 0 and y < m;
}


int countBitsFaster(int n){
    int x = 0;
    while(n>0){
        // Removes the last set bit from the current number
        n &= (n-1);
        x++;
    }
    return x;
}

int convertToBinary(int n){
	int ans = 0;
	int p = 1;
    int last_bit;

	while(n > 0){
		last_bit = (n&1);
		ans += p*last_bit;

		p *= 10;
		n >>= 1;
	}
	return ans;
}

int gcd(int a, int b) {
    if (!a || !b)
        return a | b;
    unsigned shift = __builtin_ctz(a | b);
    a >>= __builtin_ctz(a);
    do {
        b >>= __builtin_ctz(b);
        if (a > b)
            swap(a, b);
        b -= a;
    } while (b);
    
    return a << shift;
}


ll modF(ll a) {return ((a%mod)+mod)%mod; }

ll ModPow(ll b, ll p){
  if (p == 0){
    return 1;
  }
    
  if (p == 1){
    return b;
  }
    
  ll ans = ModPow(b, p/2);
  ans = (ans % mod) * (ans % mod) % mod;

  if (p&1)
    ans = (ans % mod) * (b % mod) % mod;

  return ans;
}

ll fastPowI(int a, int b){
   ll Answer = 1;
   while(b){
        if(b&1){
            Answer *= a;
        }
        a *= a;
        b >>= 1;
   }
   return Answer;
}


int main(){___


    
}