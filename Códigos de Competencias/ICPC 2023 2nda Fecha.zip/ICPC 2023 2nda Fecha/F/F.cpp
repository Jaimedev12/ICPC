// Basic
#include <bits/stdc++.h>
#include <ext/pb_ds/assoc_container.hpp>
#include <ext/pb_ds/tree_policy.hpp>
using namespace std;
using namespace __gnu_pbds;
#define endl "\n"
// Loops
#define For(i,l,r) for(int i = l; i < (r); ++i)
#define ForI(i,l,r) for(int i = l; i <= (r); ++i)
#define ForR(i,l,r) for(int i = r-1; i >= 0; i--)
#define ForRI(i,l,r) for(int i = r; i >= (l); i--)
// Shortcuts
#define ___ ios::sync_with_stdio(false);cin.tie(0);
#define pb push_back
#define popb pop_back
#define eb emplace_back
#define sz(a) ((int)((a).size()))
#define mp make_pair
#define ll long long int
// Basic DS
typedef long double ld;
typedef pair<int,int> pii;
typedef pair<ll,ll> pll;
typedef tuple<int, int, int> Tupleiii;
// Vectors
typedef vector<ll> vll;
typedef vector<string> vs;
typedef vector<char> vc;
typedef vector<int> vi;
typedef vector<bool> vb;
typedef vector<pii> vpii;
typedef vector<double> vd;
typedef vector<ld> vld;
// Matrixs
typedef vector<vi> MatrixI;
typedef vector<vc> MatrixC;
typedef vector<vb> MatrixB;
typedef vector<vld> Matrixld;
typedef vector<vpii> MatrixPii;
typedef vector<vll> MatrixLL;

//    BITS
#define LSOne(S) ((S) & -(S))  // less significant bit
#define isOn(S, j) (S & (1<<j))
#define setBit(S, j) (S |= (1<<j))
#define clearBit(S, j) (S &= ~(1<<j))
#define toggleBit(S, j) (S ^= (1<<j))
#define lowBit(S) (S & (-S))
#define setAll(S, n) (S = (1<<n)-1)

#define IPOT(S) (!(S & (S-1)))       // isPowerOfTwo ? 1:0
#define modB(S, N) ((S) & (N-1))     // returns S % N, where N is a power of 2
#define NPOT(S) (1<<lround(log2(S))) // nearestPowerOfTwo
#define offLB(S) ((S) & (S-1))       // turnOffLastBit
#define onLZ(S) ((S) | (S+1))        // turnOnLastZero
#define offLCB(S) ((S) & (S+1))      // turnOffLastConsecutiveBits
#define onLCZ(S) ((S) | (S-1))       // turnOnLastConsecutiveZeroes
// count the number of active bits
// 32 bits - __builtin_popcount(S) int
// 64 bits - __builtin_ctz(S)      long long

// Constants
const ld eps = (ld)1e-9;
#define INF 99999999999
const ll mod = 1e9 + 7;



struct Matrix {ll mat[2][2];};

ll modF(ll a) {return (((a%mod)+mod) % mod);}


Matrix matMul(Matrix a, Matrix b){
    Matrix ans;
    // Initialize
    For(i,0,2){
        For(j,0,2){
            ans.mat[i][j] = 0;
        }
    }

    For(i,0,2){
        For(g,0,2){
            if(ans.mat[i][g] == 0) continue;
            For(j,0,2){
                ans.mat[i][j] += ((  ans.mat[i][g] % mod * b.mat[g][j] ) % mod );
            }
        }
    }
    return ans;
}


Matrix matPow(Matrix base, int p){
    Matrix ans;
    // Initialize
    For(i,0,2){
        For(j,0,2){
            if(i == j){
                ans.mat[i][j] = (i == j);
            }
        }
    }

    while(p){
        if(p&1){
            ans = matMul(ans,base);
        }
        base = matMul(base,base);
        p >>= 1;
    }

    return ans;

}

ll ModPow(ll b, ll p){
  if (p == 0){
    return 1;
  }
    
  if (p == 1){
    return b;
  }
    
  ll ans = ModPow(b, p/2);
  ans = (ans % mod) * (ans % mod) % mod;

  if (p&1)
    ans = (ans % mod) * (b % mod) % mod;

  return ans;
}

int main(){___
    ll n,k;
    cin >> n >> k;
    
    
    if(n <= 10000){
        vll fib(n+5);
        fib[0] = fib[1] = 1;
        ForI(i,2,n){
            fib[i] = (fib[i-1] % mod + fib[i-2] % mod);
        }
        cout << (fib[n])<< endl;
        return 0;
    }

    Matrix fibo1;
    fibo1.mat[0][0] = fibo1.mat[1][0] = fibo1.mat[0][1] = 1;
    fibo1.mat[1][1] = 0;

    fibo1 = matPow(fibo1,n);
    ll respuesta = 

    cout << ModPow(fibo1.mat[1][0], k) - (2 * multiply) << endl;

   return 0;

    
}