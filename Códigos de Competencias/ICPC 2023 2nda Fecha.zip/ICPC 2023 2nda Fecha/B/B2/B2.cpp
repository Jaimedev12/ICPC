// Basic
#include <bits/stdc++.h>
#include <ext/pb_ds/assoc_container.hpp>
#include <ext/pb_ds/tree_policy.hpp>
using namespace std;
using namespace __gnu_pbds;
#define endl "\n"
// Loops
#define For(i,l,r) for(int i = l; i < (r); ++i)
#define ForI(i,l,r) for(int i = l; i <= (r); ++i)
#define ForR(i,l,r) for(int i = r-1; i >= 0; i--)
#define ForRI(i,l,r) for(int i = r; i >= (l); i--)
// Shortcuts
#define ___ ios::sync_with_stdio(false);cin.tie(0);
#define pb push_back
#define popb pop_back
#define eb emplace_back
#define sz(a) ((int)((a).size()))
#define ll long long int
// Basic DS
typedef long double ld;
typedef pair<int,int> pii;
typedef pair<ll,ll> pll;
typedef tuple<int, int, int> Tupleiii;
// Vectors
typedef vector<ll> vll;
typedef vector<string> vs;
typedef vector<char> vc;
typedef vector<int> vi;
typedef vector<bool> vb;
typedef vector<pii> vpii;
typedef vector<double> vd;
typedef vector<ld> vld;
// Matrixs
typedef vector<vi> MatrixI;
typedef vector<vc> MatrixC;
typedef vector<vb> MatrixB;
typedef vector<vld> Matrixld;
typedef vector<vpii> MatrixPii;
typedef vector<vll> MatrixLL;

const int maxSize = 1e6+10;
#define mod 1000000007

ll mulMod(ll a, ll b){
    return (ll)((__int128)(a) * (b) % mod);
}

ll fastPow(ll x, ll n){
    ll ret = 1;
    while(n){
        if(n&1){
            ret = mulMod(ret,x);
        }
        x = mulMod(x,x);
        n >>= 1;
    }
    return ret;
}

// Asume p is prime
ll modInverse(ll a){
    return fastPow(a, mod-2);
}



int main(){___
    int N, K;
    cin >> N >> K;
    vll dp(maxSize);
    dp[0] = 1;
    ForI(i,1,maxSize){
        dp[i] = ((dp[i-1] % mod) * (i % mod) ) % mod;
    }
    vll arr(N+10);
    unordered_map <ll, ll > mp;
    ForI(i,1,N){
        cin >> arr[i];
        mp[arr[i]]++;
    }


    ll V = 1;
    unordered_set<ll> estan;
    ForI(i,1,N){
        if(!estan.count(arr[i])){
            V = ((V % mod) *  (dp[mp[arr[i]]]  % mod)) % mod ;
            estan.insert(arr[i]);
        }
    }
    
    ll numerador = V;
    cout << "dp de N: " << dp[N] << endl;
    ll inversoModular = modInverse(dp[N]);
    ll ans = mulMod(numerador, numerador);
    cout << mulMod(inversoModular, ans) << endl;

    while(K--){
        ll A,B;
        cin >> A >> B;
        // Actualizar
        ll dividir = modInverse(mp[arr[A]]);
        numerador = mulMod(numerador,dividir );
        mp[arr[A]]--;

        // Actualizar a b
        mp[B]++;
        numerador = mulMod(numerador, mp[B]);
        arr[A] = B;

        cout << "Array" << endl;
        For(i, 0, (int)arr.size()) {
            cout << arr[i] << " ";
        }
        cout << endl;

        ans = mulMod(numerador, numerador);
        cout << ans << endl;
        cout << "Inverso: " << inversoModular << endl;
        cout << mulMod(inversoModular, 4) << endl << endl;
        //cout << mulMod(inversoModular, ans) << endl << endl;
    }

    return 0;
}