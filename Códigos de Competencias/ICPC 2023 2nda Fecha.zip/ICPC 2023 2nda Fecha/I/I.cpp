// Basic
#include <bits/stdc++.h>
#include <ext/pb_ds/assoc_container.hpp>
#include <ext/pb_ds/tree_policy.hpp>
using namespace std;
using namespace __gnu_pbds;
#define endl "\n"
// Loops
#define For(i,l,r) for(int i = l; i < (r); ++i)
#define ForI(i,l,r) for(int i = l; i <= (r); ++i)
#define ForR(i,l,r) for(int i = r-1; i >= 0; i--)
#define ForRI(i,l,r) for(int i = r; i >= (l); i--)
// Shortcuts
#define ___ ios::sync_with_stdio(false);cin.tie(0);

int main(){ ___

    int N, M, K; cin >> N >> M >> K;

    if (N/K >= M) {
        cout << "Iron fist Ketil" << endl;
    } else {
        cout << "King Canute" << endl;
    }

    return 0;
    
}